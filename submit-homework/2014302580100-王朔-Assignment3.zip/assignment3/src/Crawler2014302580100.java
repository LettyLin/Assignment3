import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Crawler2014302580100 {
	static ArrayList<String> linklist=new ArrayList<String>();
	

	public static void crawlAllsynchronizedly() throws IOException {
		// TODO Auto-generated method stub
		HttpRequest2014302580100 html = HttpRequest2014302580100.get("http://www.wpi.edu/academics/cs/research-interests.html");
		html.receive(new File("./teachers.html"));
		File HTML = new File("./teachers.html");
		Document doc = Jsoup.parse(HTML, "UTF-8","http://www.wpi.edu");
		Elements allurl=doc.getElementsByTag("a");//ѡ��half div����
		for(Element link:allurl)
		{
			linklist.add(link.attr("href"));
			findvalidlink(link);
		}
		
		CharSequence [] cs=linklist.toArray(new CharSequence[linklist.size()]);
		for(int i=0;i<20;i++)
		{
			HttpRequest2014302580100 html1=HttpRequest2014302580100.get(cs[i]);
			html1.receive(new File("./"+(i+1)+".html"));
			File file1=new File("./"+(i+1)+".html");
			getinformation(file1);
		}
	}

	private static void getinformation(File file1) throws IOException {
		
		Document d=Jsoup.parse(file1,"UTF-8");
		
		//name
		Elements a0 = d.select("div#profile+h2");
		String a1 = a0.text();
		//phone
		Elements contact=d.select("div#contactinfo p");
		String b1 = contact.text();
		Pattern pattern=Pattern.compile("Phone: (\\+\\d-\\d{3}-\\d{3}-\\d{4})");
		Matcher m=pattern.matcher(b1);
		if(m.find()){
			b1=m.group(1);
		}
		//email
		Elements email=d.select("div#contactinfo p>a");
		String a2=email.text();
		//interest
		Elements jmajor=d.select("div.col ul li");
		String b2=jmajor.text();
		Database2014302580100.insert(new Professor2014302580100(a1,b1,a2,b2));
	}


	private static void findvalidlink(Element link) {
		ArrayList<String> validlink=new ArrayList<String>();
		for(String link1:linklist)
		{
			String regex = "(www\\.wpi\\.edu/academics/(facultydir)|(datescience)/)(.+)";
			Pattern p=Pattern.compile(regex);
			Matcher m=p.matcher(link1);
			if(m.find())
			{
				validlink.add(link1);
				
			}
		}
		linklist=validlink;
//		validlink.remove(0);
//		System.out.println(linklist);
	
	}

}
