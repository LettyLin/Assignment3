//import java.awt.List;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580100 {
	static ArrayList<File> waitlist=new ArrayList<File>();
	public static void main(String[] args) throws IOException, InterruptedException {
		
		long starttime=System.currentTimeMillis();
		try
		{
			singleThread();
		}catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		System.out.println("SingleThread processing time is:"+(System.currentTimeMillis()-starttime)/1000.0+"s");
		
		long time=System.currentTimeMillis();
		try {
			multiThread();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("MultiThread processing time is:"+(System.currentTimeMillis()-time)+"ms");
	}
	private static void singleThread() throws InterruptedException, IOException{
		Crawler2014302580100.crawlAllsynchronizedly();
	}
	private static void multiThread(){
		TestThread2014302580100 t=new TestThread2014302580100();
		new Thread(t).start();
		new Thread(t).start();
	}
	
	

}
