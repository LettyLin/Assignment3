
public class TestThread2014302580100 implements Runnable{
	public void run()
	{
		while(true)
		{
			synchronized (this) {
				try {
					Crawler2014302580100.crawlAllsynchronizedly();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

}
