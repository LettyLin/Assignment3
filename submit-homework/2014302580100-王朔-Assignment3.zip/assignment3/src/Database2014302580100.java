import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.Executor;

public class Database2014302580100 {
	public static void insert(Professor2014302580100 p){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/professors"
					+ "?useUnicode=true&characterEncoding=utf-8",
					"root", "123456");
			PreparedStatement st=con.prepareCall("INSERT INTO professor values(?,?,?,?)");
			st.setString(1, p.getName());
			st.setString(2, p.getPhone());
			st.setString(3, p.getEmail());
			st.setString(4, p.getInterests());
			st.executeUpdate();
			st.close();
			con.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
