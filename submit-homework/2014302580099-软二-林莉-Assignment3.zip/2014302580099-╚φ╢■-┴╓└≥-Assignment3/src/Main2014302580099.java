import java.io.IOException;

/**
 * Created by LinLi on 2015/11/9.
 */
public class Main2014302580099{
    public static void main(String[] args) throws IOException
    {
        Crawl2014302580099 crawl = new Crawl2014302580099();
        //���߳�
        //crawl.CreateThreads();
        //���߳�
        crawl.SingleThread();
    }
}
