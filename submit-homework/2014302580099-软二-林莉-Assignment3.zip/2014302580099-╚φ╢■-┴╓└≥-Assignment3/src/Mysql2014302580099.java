import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 * Created by LinLi on 2015/11/9.
 */
public class Mysql2014302580099 {
    //单例
    public static Mysql2014302580099 myInstance = new Mysql2014302580099();
    public static Mysql2014302580099 getMyInstance(){return myInstance;}

    Connection con = null;

    public Mysql2014302580099()
    {
        setCon();
    }
    public void setCon() {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/new", "root", "123456");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void Insert(Teacher2014302580099 teacher2014302580099) {

        Statement statement = null;
        try {
            statement = con.createStatement();
            String s = "INSERT INTO new_table (name,phonenumber,email) values ('"
                    + teacher2014302580099.get_name() + "','"
                    + teacher2014302580099.get_phoneNumber() + "','"
                    + teacher2014302580099.get_email() + "');";
            statement.execute(s);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
