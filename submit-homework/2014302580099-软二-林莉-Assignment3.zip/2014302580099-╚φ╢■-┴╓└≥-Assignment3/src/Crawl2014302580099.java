import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by LinLi on 2015/11/9.
 */
public class Crawl2014302580099{
    Queue<String> urlQueue;
    Queue<String> nameQueue;

    //单线程
    class CrawlThread extends Thread {
        @Override
        public void run() {
            long startTime = System.currentTimeMillis();
            try {
                while (!urlQueue.isEmpty()) {
                    crawlInformation(urlQueue.remove(), nameQueue.poll());
                }
                long endTime = System.currentTimeMillis();
                System.out.println(endTime - startTime + "ms");
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    //多线程
    class CrawlThreads extends Thread{
        @Override
        public void run(){
            try {
                if(!urlQueue.isEmpty())
                {
                    String url;
                    synchronized (urlQueue) {
                        url = urlQueue.poll();
                    }

                    crawlInformation(url, nameQueue.poll());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void crawlInformation(String url,String name)
    {
        try {
            Teacher2014302580099 teacher2014302580099 = new Teacher2014302580099();
            Document doc = Jsoup.connect(url).get();
            if (doc == null) {
                return;
            }
            Elements info = doc.getElementById("contactinfo").getElementsByTag("p");

            Pattern pattern1 = Pattern.compile("\\+1-[0-9]{3}-[0-9]{3}-[0-9]{4}");
            Matcher matcher1 = pattern1.matcher(info.text());
            if (matcher1.find()) {
                teacher2014302580099.set_phoneNumber(matcher1.group(0));
            }

            Pattern pattern2 = Pattern.compile("[a-z]+@[a-z]+\\.edu");
            Matcher matcher2 = pattern2.matcher(info.text());
            while (matcher2.find()) {
                teacher2014302580099.set_email(matcher2.group());
            }
            teacher2014302580099.set_name(name);
            teacher2014302580099.WriteToMysql();
        }catch (Exception e)
        {
            return;//防止某子页被拔404
        }
    }

    public Crawl2014302580099() throws IOException
    {
        urlQueue = new LinkedBlockingDeque<>();
        nameQueue = new LinkedBlockingDeque<>();
        String mainURL = "http://www.wpi.edu/academics/cs/research-interests.html";
        Document doc = Jsoup.connect(mainURL).get();
        Elements divs = doc.getElementsByClass("half");

        for (Element div : divs) {
            Elements as = div.getElementsByTag("a");
            for (Element a : as) {
                String link = a.attr("href");
                String a_name = a.text();
                if (a != null && link != null && link != ""&& a_name != null && a_name != "") {
                    if(urlQueue.contains(link)||nameQueue.contains(a_name))
                    {
                        continue;
                    }
                    else{
                    urlQueue.add(link);
                    nameQueue.add(a_name);
                    }
                }
            }
        }
    }

    //多线程
    public void CreateThreads() {
        long startTime = System.currentTimeMillis();
        Thread[] threadArr = new CrawlThreads[5];
        for(int i = 0; i < threadArr.length; ++i){
            threadArr[i] = new CrawlThreads();
            threadArr[i].start();
        }

        while(!urlQueue.isEmpty()){
            for(int j=0;j<threadArr.length;++j)
            {
                if(threadArr[j].getState()== Thread.State.TERMINATED)
                {
                    threadArr[j] = new CrawlThreads();
                    threadArr[j].start();
                }
            }
        }
        long endTime = System.currentTimeMillis();
        System.out.println(endTime-startTime+"ms");
    }
    //单线程
    public void SingleThread(){
        Thread t = new CrawlThread();
        t.start();
    }
}